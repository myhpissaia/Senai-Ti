/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Aluno
 */
public class Pessoa {
    private String nome;
    private String sobrenome;
    private String RG;
    private String CPF;
    private String email;
    private String endereco;
    private String numen;
    private String cidade;
    private String estado;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the sobrenome
     */
    public String getSobrenome() {
        return sobrenome;
    }

    /**
     * @param sobrenome the sobrenome to set
     */
    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    /**
     * @return the RG
     */
    public String getRG() {
        return RG;
    }

    /**
     * @param RG the RG to set
     */
    public void setRG(String RG) {
        this.RG = RG;
    }

    /**
     * @return the CPF
     */
    public String getCPF() {
        return CPF;
    }

    /**
     * @param CPF the CPF to set
     */
    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the numen
     */
    public String getNumen() {
        return numen;
    }

    /**
     * @param numen the numen to set
     */
    public void setNumen(String numen) {
        this.numen = numen;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
    public void MostrarPessoa(){
        System.out.println("");
        System.out.println("PESSOA");
        System.out.println("Nome: "+getNome());
        System.out.println("Sobrenome: "+getSobrenome());
        System.out.println("RG: "+getRG());
        System.out.println("CPF: "+getCPF());
        System.out.println("Email: "+getEmail());
        System.out.println("Endereco: "+getEndereco());
        System.out.println("Numero Endereco: "+getNumen());
        System.out.println("Cidade: "+getCidade());
        System.out.println("Estado: "+getEstado());
        System.out.println("");

    }
    
}
