/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Aluno
 */
public class BD {
    private static  ArrayList<Empresa>empresa=new ArrayList<Empresa>();
    private static ArrayList<Pessoa>pessoa=new ArrayList<Pessoa>();

    /**
     * @return the empresa
     */
    public static ArrayList<Empresa> getEmpresa() {
        return empresa;
    }

    /**
     * @param empresa the empresa to set
     */
    public void setEmpresa(ArrayList<Empresa> empresa) {
        this.empresa = empresa;
    }

    /**
     * @return the pessoa
     */
    public static ArrayList<Pessoa> getPessoa() {
        return pessoa;
    }

    /**
     * @param pessoa the pessoa to set
     */
    public void setPessoa(ArrayList<Pessoa> pessoa) {
        this.pessoa = pessoa;
    }
    
    
}
