/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Aluno
 */
public class Empresa {
    private String nome;
    private String cnpj;
    private String cpf;
    private String endereco;
    private String numen;
    private String cidade;
    private String estado;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cnpj
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * @param cnpj the cnpj to set
     */
    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    /**
     * @return the cpf
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * @return the numen
     */
    public String getNumen() {
        return numen;
    }

    /**
     * @param numen the numen to set
     */
    public void setNumen(String numen) {
        this.numen = numen;
    }

    /**
     * @return the cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }
    public void MostrarEmpresa(){
        System.out.println("");
        System.out.println("EMPRESA");
        System.out.println("Nome: "+getNome());
        System.out.println("CNPJ: "+getCnpj());
        System.out.println("CPF: "+getCpf());
        System.out.println("Endereco: "+getEndereco());
        System.out.println("Numero Endereco: "+getNumen());
        System.out.println("Cidade: "+getCidade());
        System.out.println("Estado: "+getEstado());
        System.out.println("");
}
}
