/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import Main.CadastroEmpresa;
import Main.CadastroPessoas;
import Model.BD;
import Model.Empresa;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;


/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CadastroEmpresaController implements Initializable {

    @FXML private Button btcancelarem;
    @FXML private Button btcadastrarem;
    @FXML private TextField textnomeem;
    @FXML private TextField textcnpj;
    @FXML private TextField textcpfem;
    @FXML private TextField textenderecoem;
    @FXML private TextField textnumem;
    @FXML private TextField textcidadeem;
    @FXML private TextField textestadoem;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btcancelarem.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                CadastroEmpresa.getStage().close();
            }
            });
        btcancelarem.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                CadastroEmpresa.getStage().close();
            }
            });
        btcadastrarem.setOnMouseClicked((MouseEvent e)->{
           try{
               Empresa empre = new Empresa();
               empre.setNome(textnomeem.getText());
               empre.setCnpj(textcnpj.getText());
               empre.setCpf(textcpfem.getText());
               empre.setEndereco(textenderecoem.getText());
               empre.setNumen(textnumem.getText());
               empre.setCidade(textcidadeem.getText());
               empre.setEstado(textestadoem.getText());
               
               BD.getEmpresa().add(empre);
               CadastroEmpresa.getStage().close();
               Alert bom=new Alert (Alert .AlertType.CONFIRMATION);
               bom.setHeaderText("Cadastrado com Sucesso ");
               bom.show();
           } 
                catch (Exception ee){
                ee.printStackTrace();
                }
        });
        btcadastrarem.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
           try{
               Empresa empre = new Empresa();
               empre.setNome(textnomeem.getText());
               empre.setCnpj(textcnpj.getText());
               empre.setCpf(textcpfem.getText());
               empre.setEndereco(textenderecoem.getText());
               empre.setNumen(textnumem.getText());
               empre.setCidade(textcidadeem.getText());
               empre.setEstado(textestadoem.getText());
               
               BD.getEmpresa().add(empre);
               CadastroEmpresa.getStage().close();
               Alert bom=new Alert (Alert .AlertType.CONFIRMATION);
               bom.setHeaderText("Cadastrado com Sucesso ");
               bom.show();
           } 
                catch (Exception ee){
                ee.printStackTrace();
                }
            } });
        }
}
