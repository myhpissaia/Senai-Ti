/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import Main.CadastroPessoas;
import Model.BD;
import Model.Pessoa;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;



/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class CadastroPessoasController implements Initializable {

    @FXML private Button btcancelar;
    @FXML private Button btcadastrar;
    @FXML private TextField textnomep;
    @FXML private TextField textsobrep;
    @FXML private TextField textrg;
    @FXML private TextField textcpf;
    @FXML private TextField textemail;
    @FXML private TextField textenderecop;
    @FXML private TextField textnump;
    @FXML private TextField textcidadep;
    @FXML private TextField textestadop;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btcancelar.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                CadastroPessoas.getStage().close();
            }
            });
         btcancelar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {
                CadastroPessoas.getStage().close();
            }
         });
         
        btcadastrar.setOnMouseClicked((MouseEvent e)->{   
            try{
                Pessoa pessoas = new Pessoa();
                pessoas.setNome(textnomep.getText());
                pessoas.setSobrenome(textsobrep.getText());
                pessoas.setRG(textrg.getText());
                pessoas.setCPF(textcpf.getText());
                pessoas.setEmail(textemail.getText());
                pessoas.setEndereco(textenderecop.getText());
                pessoas.setNumen(textnump.getText());
                pessoas.setCidade(textcidadep.getText());
                pessoas.setEstado(textestadop.getText());
                    
                BD.getPessoa().add(pessoas);
                CadastroPessoas.getStage().close();
                Alert boa=new Alert (Alert .AlertType.CONFIRMATION);
                boa.setHeaderText("Cadastrado com Sucesso ");
                boa.show();
            }
            catch (Exception ee){
                ee.printStackTrace();
            }
            });
         btcadastrar.setOnKeyPressed((KeyEvent evt) -> {
            if (evt.getCode() == KeyCode.ENTER) {  
            try{
                Pessoa pessoas = new Pessoa();
                pessoas.setNome(textnomep.getText());
                pessoas.setSobrenome(textsobrep.getText());
                pessoas.setRG(textrg.getText());
                pessoas.setCPF(textcpf.getText());
                pessoas.setEmail(textemail.getText());
                pessoas.setEndereco(textenderecop.getText());
                pessoas.setNumen(textnump.getText());
                pessoas.setCidade(textcidadep.getText());
                pessoas.setEstado(textestadop.getText());
                    
                BD.getPessoa().add(pessoas);
                CadastroPessoas.getStage().close();
                Alert boa=new Alert (Alert .AlertType.CONFIRMATION);
                boa.setHeaderText("Cadastrado com Sucesso ");
                boa.show();
            }
            catch (Exception ee){
                ee.printStackTrace();
            }
            } });
    }    
}

